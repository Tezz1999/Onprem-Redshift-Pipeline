from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from datetime import datetime, timedelta
import pandas as pd
from sqlalchemy import create_engine
from airflow.hooks.base import BaseHook
from io import StringIO

def extract_data_from_postgres():
    connection = BaseHook.get_connection('postgres_docker')
    engine = create_engine(f'postgresql+psycopg2://{connection.login}:{connection.password}@{connection.host}/{connection.schema}')
    query = "SELECT * FROM hate_crime_maddirt"
    df = pd.read_sql(query, engine)
    return df

def upload_to_s3(bucket_name, df, key):
    # Convert DataFrame to CSV
    csv_buffer = StringIO()
    df.to_csv(csv_buffer, index=False)
    csv_buffer.seek(0)  # Go to the start of the StringIO buffer

    # Use S3Hook to upload the file
    s3_hook = S3Hook(aws_conn_id='s3_conn')
    s3_hook.load_string(csv_buffer.getvalue(), key, bucket_name=bucket_name, replace=True)

def data_pipeline():
    df = extract_data_from_postgres()

    # Define your S3 bucket and key
    bucket_name = 'myreddataproject'
    current_date = datetime.now().strftime("%Y-%m-%d")
    s3_key = f'data/hate_crime_maddirt_{current_date}.csv'
    
    # Upload data to S3
    upload_to_s3(bucket_name, df, s3_key)

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 2, 9),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=1),
}

dag = DAG('postgres_to_redshift_via_s3hook', default_args=default_args, schedule_interval=timedelta(days=1), catchup=False)

run_pipeline = PythonOperator(
    task_id='run_data_pipeline',
    python_callable=data_pipeline,
    dag=dag,
)

run_pipeline


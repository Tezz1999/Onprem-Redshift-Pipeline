from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.hooks.base import BaseHook
import pandas as pd
from sqlalchemy import create_engine
import logging
from airflow.models import Variable

# Function to create a table in the database
def create_postgres_table():
    try:
        connection = BaseHook.get_connection('postgres_docker')
        engine = create_engine(f'postgresql+psycopg2://{connection.login}:{connection.password}@{connection.host}/{connection.schema}')

        create_table_sql = """
        CREATE TABLE IF NOT EXISTS hate_crime_maddirt (
        incident_id INT,
        data_year INT,  -- Changed from YEAR to INT
        ori VARCHAR(20),
        pug_agency_name VARCHAR(255),
        agency_type_name VARCHAR(50),
        state_name VARCHAR(50),
        population_group_description VARCHAR(255),
        incident_date DATE,
        total_offender_count INT,
        offender_race VARCHAR(50),
        victim_count INT,
        offense_name VARCHAR(255),
        location_name VARCHAR(255)
            );
        """
        with engine.connect() as conn:
            conn.execute(create_table_sql)
        logging.info("Table created successfully.")
    except Exception as e:
        logging.error(f"Error creating table: {e}")

# Function to load data into the table
def load_data_to_postgres():
    try:
        connection = BaseHook.get_connection('postgres_docker')
        engine = create_engine(f'postgresql+psycopg2://{connection.login}:{connection.password}@{connection.host}/{connection.schema}')

        csv_file_path = "/opt/airflow/plugins/hate_crime.csv"  # Update the path as needed
        data = pd.read_csv(csv_file_path)

        columns_to_insert = [
            'incident_id', 'data_year', 'ori', 'pug_agency_name', 
            'agency_type_name', 'state_name', 'population_group_description', 
            'incident_date', 'total_offender_count', 'offender_race', 
            'victim_count', 'offense_name', 'location_name'
        ]
        data_filtered = data[columns_to_insert]
        data_filtered.to_sql('hate_crime_maddirt', con=engine, if_exists='append', index=False)
        logging.info("Data loaded successfully.")
    except Exception as e:
        logging.error(f"Error loading data: {e}")

# Default arguments for the DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 2),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(seconds=20),
}

# Define the DAG
with DAG(
    'postgres_data_loading_dag',
    default_args=default_args,
    description='Create table and load data into PostgreSQL',
    schedule_interval=timedelta(days=1),
    catchup=False,
) as dag:

    create_table_task = PythonOperator(
        task_id='create_postgres_table',
        python_callable=create_postgres_table,
    )

    load_data_task = PythonOperator(
        task_id='load_data_to_postgres',
        python_callable=load_data_to_postgres,
    )

    create_table_task >> load_data_task

